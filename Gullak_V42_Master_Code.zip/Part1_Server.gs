/**
 * 🏦 GULLAK CO-OPERATIVE SOCIETY - BACKEND CONTROLLER (V42 PRO MASTER)
 * Standardized Sheets + Auto-Cleanup + Strict ID Formats + Sheet Protection ('Password') + Users Auth
 */

function onOpen() {
  SpreadsheetApp.getUi().createMenu("🏦 Gullak Co-operative")
    .addItem("⚡ 1. Initialize & Organize Sheet Database", "installAndRunDatabase")
    .addItem("🔑 2. Update / Reset Users & Passwords to 12345", "resetUsersCredentialsToDefault")
    .addItem("🌐 3. Get Live Web App URL", "showWebPortalUrl")
    .addItem("✉️ 4. Authorize Email Sending Permission", "testEmailPermission")
    .addToUi();

  // Auto-upgrade legacy credentials in Users sheet on open
  try {
    upgradeUsersSheetCredentials();
  } catch(e) {}
}

function testEmailPermission() {
  try {
    var email = Session.getActiveUser().getEmail() || "stfsolutionsdelhi@gmail.com";
    MailApp.sendEmail(email, "Gullak Society - Email Permission Test", "Email dispatch permissions verified successfully.");
    SpreadsheetApp.getUi().alert("✅ Email Sending Permission Verified!\n\nEmail dispatch is successfully authorized for your Google Account.");
  } catch(e) {
    SpreadsheetApp.getUi().alert("Notice: " + e.toString());
  }
}

function showWebPortalUrl() {
  try {
    var url = ScriptApp.getService().getUrl();
    if (!url) {
      SpreadsheetApp.getUi().alert("Please deploy Web App first:\nDeploy > New deployment > Web app > Anyone");
    } else {
      SpreadsheetApp.getUi().alert("🌐 Your Live Web Portal URL:\n\n" + url);
    }
  } catch (e) {
    SpreadsheetApp.getUi().alert("Deploy Web App from Deploy > New deployment.");
  }
}

function getSpreadsheetUrl() {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    return ss ? ss.getUrl() : "";
  } catch(e) {
    return "";
  }
}

function upgradeUsersSheetCredentials() {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    if (!ss) return;
    var userSheet = ss.getSheetByName("Users");
    if (!userSheet) return;
    if (userSheet.getLastRow() <= 1) {
      userSheet.appendRow(["SANISH", "12345", "Super Admin", "stfsolutionsdelhi@gmail.com", "ACTIVE", new Date()]);
      userSheet.appendRow(["ADMIN", "12345", "Manager", "stfsolutionsdelhi@gmail.com", "ACTIVE", new Date()]);
      SpreadsheetApp.flush();
      return;
    }
    var numRows = userSheet.getLastRow() - 1;
    var data = userSheet.getRange(2, 1, numRows, Math.min(6, userSheet.getLastColumn())).getValues();
    var changed = false;
    for (var i = 0; i < data.length; i++) {
      var u = String(data[i][0] || "").trim().toUpperCase();
      var p = String(data[i][1] || "").trim();
      var em = String(data[i][3] || "").trim();
      var rowNum = i + 2;
      if (p === "Password" || p === "Admin@123" || p === "") {
        userSheet.getRange(rowNum, 2).setValue("12345");
        changed = true;
      }
      if ((u === "SANISH" || u === "ADMIN") && (p === "Password" || p === "Admin@123")) {
        userSheet.getRange(rowNum, 2).setValue("12345");
        changed = true;
      }
      if (!em || em.indexOf("@") === -1) {
        userSheet.getRange(rowNum, 4).setValue("stfsolutionsdelhi@gmail.com");
        changed = true;
      }
    }
    if (changed) SpreadsheetApp.flush();
  } catch(e) {}
}

function resetUsersCredentialsToDefault() {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    if (!ss) return;
    var userSheet = ss.getSheetByName("Users");
    if (!userSheet) {
      installAndRunDatabase();
      return;
    }
    userSheet.clearContents();
    var userH = ["Username", "Password", "Role", "Email", "Status", "CreatedAt"];
    userSheet.getRange(1, 1, 1, userH.length).setValues([userH]);
    userSheet.appendRow(["SANISH", "12345", "Super Admin", "stfsolutionsdelhi@gmail.com", "ACTIVE", new Date()]);
    userSheet.appendRow(["ADMIN", "12345", "Manager", "stfsolutionsdelhi@gmail.com", "ACTIVE", new Date()]);
    SpreadsheetApp.flush();
    SpreadsheetApp.getUi().alert("✅ Users Tab Updated Successfully!\n\n• Username: SANISH, Password: 12345\n• Username: ADMIN, Password: 12345\n• Registered Email: stfsolutionsdelhi@gmail.com\n\nAap is tab me Column B me password aur Column D me email kabhi bhi change kar sakte hain.");
  } catch(e) {
    try { SpreadsheetApp.getUi().alert("Error: " + e.toString()); } catch(err) {}
  }
}

function sendCredentialsEmailBackend(targetUsername) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var uSheet = ss ? ss.getSheetByName("Users") : null;
    var foundUser = null;
    var defaultEmail = "stfsolutionsdelhi@gmail.com";

    if (uSheet && uSheet.getLastRow() > 1) {
      var uData = uSheet.getRange(2, 1, uSheet.getLastRow() - 1, Math.min(6, uSheet.getLastColumn())).getValues();
      var cleanTarget = String(targetUsername || "").trim().toUpperCase();
      if (cleanTarget) {
        for (var i = 0; i < uData.length; i++) {
          if (String(uData[i][0]).trim().toUpperCase() === cleanTarget) {
            foundUser = {
              username: String(uData[i][0]).trim(),
              password: String(uData[i][1]).trim() || "12345",
              role: String(uData[i][2] || "Manager").trim(),
              email: String(uData[i][3] || defaultEmail).trim()
            };
            break;
          }
        }
      }
      if (!foundUser && uData.length > 0) {
        foundUser = {
          username: String(uData[0][0]).trim(),
          password: String(uData[0][1]).trim() || "12345",
          role: String(uData[0][2] || "Super Admin").trim(),
          email: String(uData[0][3] || defaultEmail).trim()
        };
      }
    }

    if (!foundUser) {
      foundUser = {
        username: (String(targetUsername || "").toUpperCase() === "ADMIN" ? "ADMIN" : "SANISH"),
        password: "12345",
        role: "Super Admin",
        email: defaultEmail
      };
    }

    var recipientEmail = defaultEmail;
    if (foundUser.email && foundUser.email.indexOf("@") > 0) {
      recipientEmail = foundUser.email;
    }

    var subject = "🔐 Gullak Co-operative Portal - Login Credentials Recovery";
    var body = "Namaste " + foundUser.username + ",\n\n" +
      "Aapke anurodh par Gullak Co-operative Society Accounting Portal ke login credentials bheje ja rahe hain:\n\n" +
      "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
      "👤 USERNAME : " + foundUser.username + "\n" +
      "🔑 PASSWORD : " + foundUser.password + "\n" +
      "🛡️ ROLE     : " + foundUser.role + "\n" +
      "📧 EMAIL    : " + recipientEmail + "\n" +
      "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
      "💡 Password ya Email badalne ke liye:\n" +
      "Apne connected Google Sheet ke 'Users' tab me jaakar Column B (Password) aur Column D (Email) ko update karein.\n\n" +
      "Date & Time: " + new Date().toLocaleString() + "\n" +
      "Gullak Co-operative Society Automated Management System";

    try {
      MailApp.sendEmail(recipientEmail, subject, body);
    } catch(mailErr) {
      try {
        GmailApp.sendEmail(recipientEmail, subject, body);
      } catch(gmailErr) {
        return {
          success: false,
          error: "Permission Required: Google Apps Script me Mail permission grant karni hogi. Ek baar Google Sheet me '🏦 Gullak Co-operative' menu me jaakar '✉️ 4. Authorize Email Sending Permission' par click karke Google Authorization allow karein. Tab tak aap 'Users' tab se apna password dekh/update kar sakte hain."
        };
      }
    }

    var parts = recipientEmail.split("@");
    var masked = parts[0].substring(0, Math.min(3, parts[0].length)) + "***@" + parts[1];
    return {
      success: true,
      email: masked,
      username: foundUser.username,
      message: "Credentials safaltapoorvak aapke registered email (" + masked + ") par bhej diye gaye hain!"
    };
  } catch(err) {
    return { success: false, error: err.toString() };
  }
}

function installAndRunDatabase() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) return;

  // 1. Clean unusable sheets (Sheet1, Dashboard, Fin)
  var unwanted = ["Sheet1", "Dashboard", "Fin"];
  unwanted.forEach(function(sName) {
    var s = ss.getSheetByName(sName);
    if (s && ss.getSheets().length > 1) {
      try { ss.deleteSheet(s); } catch (e) {}
    }
  });

  // Users Sheet for Multi-User Login & Roles
  var userH = ["Username", "Password", "Role", "Email", "Status", "CreatedAt"];
  var userSheet = getOrCreateSheet(ss, "Users", userH, "#0F172A");
  if (userSheet.getLastRow() <= 1) {
    userSheet.appendRow(["SANISH", "12345", "Super Admin", "stfsolutionsdelhi@gmail.com", "ACTIVE", new Date()]);
    userSheet.appendRow(["ADMIN", "12345", "Manager", "stfsolutionsdelhi@gmail.com", "ACTIVE", new Date()]);
  } else {
    try {
      var existVals = userSheet.getRange(2, 1, userSheet.getLastRow() - 1, 2).getValues();
      for (var uR = 0; uR < existVals.length; uR++) {
        var oldP = String(existVals[uR][1] || "").trim();
        if (oldP === "Password" || oldP === "Admin@123") {
          userSheet.getRange(uR + 2, 2).setValue("12345");
        }
      }
    } catch(err) {}
  }

  // Exactly 14 Columns Standard Header for Members
  var memH = ["Member ID", "Full Name", "Mobile Number", "Address", "Nominee / Ref", "RD / Month (₹)", "Status", "Date Joined", "Opening RD (₹)", "Due Day", "Custom Loan Limit (₹)", "Opening Loan (₹)", "Opening Int (₹)", "Opening Pen (₹)"];
  var memSheet = getOrCreateSheet(ss, "Members", memH, "#1E293B");

  // Standard 14 Columns Header for Payments
  var payH = ["Receipt No", "Date", "Member ID", "Name", "RD Amount (₹)", "Interest (₹)", "Penalty (₹)", "Loan Repayment (₹)", "Waiver (₹)", "Total (₹)", "Mode", "Recorded By", "Type", "Narration"];
  var paySheet = getOrCreateSheet(ss, "Payments", payH, "#0F766E");

  var loanH = ["Loan ID", "Date", "Member ID", "Name", "Type", "Principal (₹)", "Rate (%)", "Repaid (₹)", "Outstanding (₹)", "Status", "Narration"];
  var loanSheet = getOrCreateSheet(ss, "Loans", loanH, "#991B1B");

  var exitH = ["Exit ID", "Date", "Member ID", "Name", "Total RD (₹)", "Loan Dues (₹)", "Bonus Adj (₹)", "NPA Loss (₹)", "Waiver (₹)", "Net Settlement (₹)", "Status"];
  getOrCreateSheet(ss, "ExitSettlements", exitH, "#7F1D1D");

  var bonusH = ["Settlement ID", "Date", "Member ID", "Name", "Total Bonus (₹)", "Adj Loan (₹)", "Adj Interest (₹)", "Adj RD (₹)", "Adj Penalty (₹)", "Net Paid (₹)", "Mode"];
  getOrCreateSheet(ss, "BonusSettlements", bonusH, "#D97706");

  var fundH = ["Txn ID", "Date", "Type", "Account", "Entity", "Amount (₹)", "Narration", "CreatedAt"];
  var fundSheet = getOrCreateSheet(ss, "FundRegister", fundH, "#4338CA");
  alignAndFormatSheet(fundSheet, [0, 1, 2, 3, 5]);
  if (fundSheet.getLastRow() <= 1) {
    fundSheet.appendRow(["FND-260101-001", "2026-01-01", "INVEST", "BANK", "Initial Society Capital", 45000, "Opening Reserve Fund", new Date()]);
  }

  // Financials Sheet (Auto-populated Metrics)
  var finH = ["Metric / Category", "Value (₹)", "Description", "Last Updated"];
  getOrCreateSheet(ss, "Financials", finH, "#0284C7");

  // Format and align sheets
  alignAndFormatSheet(memSheet, [0, 2, 5, 6, 7, 8, 9, 10, 11, 12, 13]);
  alignAndFormatSheet(paySheet, [0, 1, 2, 4, 5, 6, 7, 8, 9, 10, 11, 12]);
  alignAndFormatSheet(loanSheet, [0, 1, 2, 5, 6, 7, 8, 9]);

  // Re-check and delete Sheet1 if present
  var sheet1 = ss.getSheetByName("Sheet1");
  if (sheet1 && ss.getSheets().length > 1) {
    try { ss.deleteSheet(sheet1); } catch (e) {}
  }

  try {
    ss.getSheets().forEach(function(s) {
      var protections = s.getProtections(SpreadsheetApp.ProtectionType.SHEET);
      if (protections.length === 0) {
        var p = s.protect().setDescription("Gullak Master Protected (Password: Password)");
        p.setWarningOnly(true);
      }
    });
  } catch (e) {}

  if (memSheet.getLastRow() <= 1) {
    var sampleM = [
      ["MEM010120261", "Rahul Kumar", "9810011111", "H-12, Sector 3, Rohini", "Sunita Kumar (Wife)", 400, "ACTIVE", "2026-01-01", 4800, "15th of every month", 0, 0, 0, 0],
      ["MEM010120262", "Suresh Sharma", "9810022222", "Shop 4, Main Market", "Vikas Sharma (Son)", 400, "ACTIVE", "2026-01-01", 4400, "15th of every month", 0, 0, 0, 0],
      ["MEM010120263", "Amit Verma", "9810033333", "B-45, Shastri Nagar", "Pooja Verma (Wife)", 400, "ACTIVE", "2026-01-01", 4400, "15th of every month", 0, 0, 0, 0],
      ["MEM010120264", "SANISH", "9718174244", "ASD", "DFFF", 400, "ACTIVE", "2026-01-01", 1000, "15th of every month", 0, 0, 0, 0]
    ];
    memSheet.getRange(2, 1, sampleM.length, 14).setValues(sampleM);
  }

  // Refresh Financials Summary
  syncFinancialsSheetBackend();
  SpreadsheetApp.flush();
}

function buildHeaderMap(sheet) {
  var map = {};
  if (!sheet || sheet.getLastRow() < 1) return map;
  var headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  for (var i = 0; i < headers.length; i++) {
    var h = String(headers[i] || "").toLowerCase().trim();
    if (h) map[h] = i;
  }
  return map;
}

function getValByHeader(row, map, possibleKeys, fallbackIdx, defaultVal) {
  if (map) {
    for (var k = 0; k < possibleKeys.length; k++) {
      var key = possibleKeys[k].toLowerCase();
      if (map.hasOwnProperty(key)) {
        var idx = map[key];
        if (idx < row.length && row[idx] !== "" && row[idx] !== null && row[idx] !== undefined) {
          return row[idx];
        }
      }
    }
  }
  if (fallbackIdx >= 0 && fallbackIdx < row.length && row[fallbackIdx] !== "" && row[fallbackIdx] !== null && row[fallbackIdx] !== undefined) {
    return row[fallbackIdx];
  }
  return defaultVal;
}

function syncFinancialsSheetBackend() {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    if (!ss) return;
    var finH = ["Metric / Category", "Value (₹)", "Description", "Last Updated"];
    var finSheet = getOrCreateSheet(ss, "Financials", finH, "#0284C7");
    
    var data = getSocietyFullDataWithoutFinSync();
    var members = data.members || [];
    var payments = data.payments || [];
    var loans = data.loans || [];
    var fundTxns = data.fundTransactions || [];

    var activeMemCount = 0;
    var totalRdTarget = 0;
    members.forEach(function(m){
      if (m.status === "ACTIVE") {
        activeMemCount++;
        totalRdTarget += Math.round(Number(m.rd)) || 400;
      }
    });

    var totalRdCollected = 0;
    var totalIntCollected = 0;
    var totalPenCollected = 0;
    var totalLoanRepaid = 0;
    payments.forEach(function(p){
      totalRdCollected += Math.round(Number(p.rd)) || 0;
      totalIntCollected += Math.round(Number(p.interest)) || 0;
      totalPenCollected += Math.round(Number(p.penalty)) || 0;
      totalLoanRepaid += Math.round(Number(p.loanRepay)) || 0;
    });

    var totalLoanDisbursed = 0;
    var totalLoanOutstanding = 0;
    loans.forEach(function(l){
      totalLoanDisbursed += Math.round(Number(l.principal)) || 0;
      if (l.status === "ACTIVE") {
        totalLoanOutstanding += Math.round(Number(l.outstanding)) || 0;
      }
    });

    var cashBal = 0;
    var bankBal = 45000;
    fundTxns.forEach(function(f){
      var amt = Math.round(Number(f.amount)) || 0;
      var isBank = String(f.account).toUpperCase().indexOf("BANK") >= 0;
      var isIn = String(f.type).toUpperCase() === "INVEST" || String(f.type).toUpperCase() === "INFLOW";
      if (isIn) {
        if (isBank) bankBal += amt; else cashBal += amt;
      } else {
        if (isBank) bankBal -= amt; else cashBal -= amt;
      }
    });

    payments.forEach(function(p){
      var tot = Math.round(Number(p.total)) || 0;
      if (p.mode === "ONLINE") bankBal += tot; else cashBal += tot;
    });

    loans.forEach(function(l){
      var pr = Math.round(Number(l.principal)) || 0;
      cashBal -= pr;
    });

    var totalLiquid = cashBal + bankBal;
    var nowStr = new Date().toLocaleString("en-IN");

    var metrics = [
      ["Total Active Members", activeMemCount, "Count of currently active society members", nowStr],
      ["Monthly RD Commitment (₹)", totalRdTarget, "Total monthly RD target across active members", nowStr],
      ["Total RD Collection (₹)", totalRdCollected, "Cumulative RD deposits collected from members", nowStr],
      ["Total Loans Disbursed (₹)", totalLoanDisbursed, "Cumulative principal amount issued as loans", nowStr],
      ["Total Loans Outstanding (₹)", totalLoanOutstanding, "Remaining principal dues on active loans", nowStr],
      ["Total Loan Interest Earned (₹)", totalIntCollected, "Cumulative interest collected from loan repayments", nowStr],
      ["Total Overdue Penalty Earned (₹)", totalPenCollected, "Cumulative penalty charges collected", nowStr],
      ["Cash in Hand Balance (₹)", cashBal, "Net liquid cash balance in physical safe", nowStr],
      ["Bank / Online Balance (₹)", bankBal, "Net liquid balance in society bank account", nowStr],
      ["Net Liquid Funds Available (₹)", totalLiquid, "Total Cash + Bank liquid reserves", nowStr],
      ["Society Net Asset Surplus (₹)", totalRdCollected + totalIntCollected + totalPenCollected - totalLoanOutstanding, "Total RD & income less outstanding loans", nowStr]
    ];

    finSheet.getRange(2, 1, finSheet.getLastRow() > 1 ? finSheet.getLastRow() - 1 : 1, 4).clearContents();
    finSheet.getRange(2, 1, metrics.length, 4).setValues(metrics);
    alignAndFormatSheet(finSheet, [1, 3]);
    SpreadsheetApp.flush();
  } catch(err) {}
}

function getSocietyFullDataWithoutFinSync() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) return getDefaultDataFallback();

  var memSheet = ss.getSheetByName("Members");
  var members = [];
  if (memSheet && memSheet.getLastRow() > 1) {
    var mMap = buildHeaderMap(memSheet);
    var mData = memSheet.getRange(2, 1, memSheet.getLastRow() - 1, memSheet.getLastColumn()).getValues();
    mData.forEach(function(r) {
      var idVal = String(getValByHeader(r, mMap, ["member id", "id"], 0, ""));
      var nameVal = String(getValByHeader(r, mMap, ["full name", "name"], 1, ""));
      if (idVal || nameVal) {
        var safeRd = Math.round(Number(getValByHeader(r, mMap, ["rd / month (₹)", "rd / month", "rd amount", "rd"], 5, 400))) || 400;
        if (safeRd <= 0 || safeRd > 50000) safeRd = 400;
        var safeOpRd = Math.round(Number(getValByHeader(r, mMap, ["opening rd (₹)", "opening balance", "opening rd", "rd paid"], 8, 0))) || 0;
        members.push({
          id: idVal,
          name: nameVal,
          mobile: String(getValByHeader(r, mMap, ["mobile number", "mobile", "phone"], 2, "")),
          address: String(getValByHeader(r, mMap, ["address", "full address"], 3, "")),
          nominee: String(getValByHeader(r, mMap, ["nominee / ref", "nominee", "reference"], 4, "")),
          rd: safeRd,
          status: String(getValByHeader(r, mMap, ["status"], 6, "ACTIVE")).toUpperCase(),
          dateJoined: formatPureDate(getValByHeader(r, mMap, ["date joined", "date"], 7, "2026-01-01")),
          rdPaid: safeOpRd,
          dueDay: String(getValByHeader(r, mMap, ["due day", "due date"], 9, "15th of every month")),
          customLimit: Math.round(Number(getValByHeader(r, mMap, ["custom loan limit (₹)", "custom limit"], 10, 0))) || 0,
          opLoan: Math.round(Number(getValByHeader(r, mMap, ["opening loan (₹)", "op loan"], 11, 0))) || 0,
          opInt: Math.round(Number(getValByHeader(r, mMap, ["opening int (₹)", "op int"], 12, 0))) || 0,
          opPen: Math.round(Number(getValByHeader(r, mMap, ["opening pen (₹)", "op pen"], 13, 0))) || 0
        });
      }
    });
  }

  var payments = [];
  var paySheet = ss.getSheetByName("Payments");
  if (paySheet && paySheet.getLastRow() > 1) {
    var pMap = buildHeaderMap(paySheet);
    var pData = paySheet.getRange(2, 1, paySheet.getLastRow() - 1, paySheet.getLastColumn()).getValues();
    pData.forEach(function(p) {
      var rNo = String(getValByHeader(p, pMap, ["receipt no", "receiptno", "receipt"], 0, ""));
      var pId = String(getValByHeader(p, pMap, ["member id", "id"], 2, ""));
      if (rNo || pId) {
        var rawMode = String(getValByHeader(p, pMap, ["mode"], 10, "CASH")).toUpperCase().trim();
        var cleanMode = (rawMode.indexOf("ONLINE") >= 0 || rawMode.indexOf("UPI") >= 0 || rawMode.indexOf("BANK") >= 0) ? "ONLINE" : "CASH";
        payments.push({
          receiptNo: rNo,
          date: formatPureDate(getValByHeader(p, pMap, ["date"], 1, "2026-01-01")),
          id: pId,
          name: String(getValByHeader(p, pMap, ["member name", "name"], 3, "")),
          rd: Math.round(Number(getValByHeader(p, pMap, ["rd amount (₹)", "rd amount", "rd"], 4, 0))) || 0,
          interest: Math.round(Number(getValByHeader(p, pMap, ["loan interest (₹)", "interest (₹)", "interest"], 5, 0))) || 0,
          penalty: Math.round(Number(getValByHeader(p, pMap, ["fine / penalty (₹)", "penalty (₹)", "penalty", "fine"], 6, 0))) || 0,
          loanRepay: Math.round(Number(getValByHeader(p, pMap, ["principal repay (₹)", "loan repayment (₹)", "loan repay"], 7, 0))) || 0,
          waiver: Math.round(Number(getValByHeader(p, pMap, ["waiver (₹)", "waiver"], 8, 0))) || 0,
          total: Math.round(Number(getValByHeader(p, pMap, ["total (₹)", "total"], 9, 0))) || 0,
          mode: cleanMode,
          by: String(getValByHeader(p, pMap, ["recorded by", "by"], 11, "Admin")),
          type: String(getValByHeader(p, pMap, ["type"], 12, "REGULAR")),
          narration: String(getValByHeader(p, pMap, ["narration"], 13, ""))
        });
      }
    });
  }

  var loans = [];
  var loanSheet = ss.getSheetByName("Loans");
  if (loanSheet && loanSheet.getLastRow() > 1) {
    var lMap = buildHeaderMap(loanSheet);
    var lData = loanSheet.getRange(2, 1, loanSheet.getLastRow() - 1, loanSheet.getLastColumn()).getValues();
    lData.forEach(function(l) {
      var lId = String(getValByHeader(l, lMap, ["loan id", "id"], 0, ""));
      var mId = String(getValByHeader(l, lMap, ["member id", "id"], 2, ""));
      if (lId || mId) {
        loans.push({
          loanId: lId,
          date: formatPureDate(getValByHeader(l, lMap, ["date"], 1, "2026-01-01")),
          id: mId,
          name: String(getValByHeader(l, lMap, ["name", "member name"], 3, "")),
          type: String(getValByHeader(l, lMap, ["type"], 4, "Gullak Loan")),
          principal: Math.round(Number(getValByHeader(l, lMap, ["principal (₹)", "principal"], 5, 0))) || 0,
          rate: Number(getValByHeader(l, lMap, ["rate (%)", "rate"], 6, 1.0)) || 1.0,
          repaid: Math.round(Number(getValByHeader(l, lMap, ["repaid (₹)", "repaid"], 7, 0))) || 0,
          outstanding: Math.round(Number(getValByHeader(l, lMap, ["outstanding (₹)", "outstanding"], 8, 0))) || 0,
          status: String(getValByHeader(l, lMap, ["status"], 9, "ACTIVE")),
          narration: String(getValByHeader(l, lMap, ["narration"], 10, ""))
        });
      }
    });
  }

  var exitSettlements = [];
  var exitSheet = ss.getSheetByName("ExitSettlements");
  if (exitSheet && exitSheet.getLastRow() > 1) {
    var exMap = buildHeaderMap(exitSheet);
    var exData = exitSheet.getRange(2, 1, exitSheet.getLastRow() - 1, exitSheet.getLastColumn()).getValues();
    exData.forEach(function(e) {
      var exId = String(getValByHeader(e, exMap, ["exit id", "id"], 0, ""));
      if (exId) {
        exitSettlements.push({
          exitId: exId,
          date: formatPureDate(getValByHeader(e, exMap, ["date"], 1, "2026-01-01")),
          id: String(getValByHeader(e, exMap, ["member id", "id"], 2, "")),
          name: String(getValByHeader(e, exMap, ["name", "member name"], 3, "")),
          totalRd: Math.round(Number(getValByHeader(e, exMap, ["total rd (₹)", "total rd"], 4, 0))) || 0,
          loanDues: Math.round(Number(getValByHeader(e, exMap, ["loan dues (₹)", "loan dues"], 5, 0))) || 0,
          bonusAdj: Math.round(Number(getValByHeader(e, exMap, ["bonus adj (₹)", "bonus adj"], 6, 0))) || 0,
          npaLoss: Math.round(Number(getValByHeader(e, exMap, ["npa loss (₹)", "npa loss"], 7, 0))) || 0,
          waiver: Math.round(Number(getValByHeader(e, exMap, ["waiver (₹)", "waiver"], 8, 0))) || 0,
          netSettlement: Math.round(Number(getValByHeader(e, exMap, ["net settlement (₹)", "net settlement"], 9, 0))) || 0,
          status: String(getValByHeader(e, exMap, ["status"], 10, "INACTIVE"))
        });
      }
    });
  }

  var bonusSettlements = [];
  var bonusSheet = ss.getSheetByName("BonusSettlements");
  if (bonusSheet && bonusSheet.getLastRow() > 1) {
    var bMap = buildHeaderMap(bonusSheet);
    var bData = bonusSheet.getRange(2, 1, bonusSheet.getLastRow() - 1, bonusSheet.getLastColumn()).getValues();
    bData.forEach(function(b) {
      var sId = String(getValByHeader(b, bMap, ["settlement id", "id"], 0, ""));
      if (sId) {
        var bMode = String(getValByHeader(b, bMap, ["mode"], 10, "ONLINE")).toUpperCase().indexOf("CASH") >= 0 ? "CASH" : "ONLINE";
        bonusSettlements.push({
          settlementId: sId,
          date: formatPureDate(getValByHeader(b, bMap, ["date"], 1, "2026-01-01")),
          id: String(getValByHeader(b, bMap, ["member id", "id"], 2, "")),
          name: String(getValByHeader(b, bMap, ["name", "member name"], 3, "")),
          totalBonus: Math.round(Number(getValByHeader(b, bMap, ["total bonus (₹)", "total bonus"], 4, 0))) || 0,
          adjLoan: Math.round(Number(getValByHeader(b, bMap, ["adj loan (₹)", "adj loan"], 5, 0))) || 0,
          adjInterest: Math.round(Number(getValByHeader(b, bMap, ["adj interest (₹)", "adj interest"], 6, 0))) || 0,
          adjRd: Math.round(Number(getValByHeader(b, bMap, ["adj rd (₹)", "adj rd"], 7, 0))) || 0,
          adjPenalty: Math.round(Number(getValByHeader(b, bMap, ["adj penalty (₹)", "adj penalty"], 8, 0))) || 0,
          netPaid: Math.round(Number(getValByHeader(b, bMap, ["net paid (₹)", "net paid"], 9, 0))) || 0,
          mode: bMode
        });
      }
    });
  }

  var fundTransactions = [];
  var fundSheet = ss.getSheetByName("FundRegister");
  if (fundSheet && fundSheet.getLastRow() > 1) {
    var fMap = buildHeaderMap(fundSheet);
    var fData = fundSheet.getRange(2, 1, fundSheet.getLastRow() - 1, fundSheet.getLastColumn()).getValues();
    fData.forEach(function(f) {
      var tId = String(getValByHeader(f, fMap, ["txn id", "id"], 0, ""));
      if (tId) {
        fundTransactions.push({
          id: tId,
          date: formatPureDate(getValByHeader(f, fMap, ["date"], 1, "2026-01-01")),
          type: String(getValByHeader(f, fMap, ["type"], 2, "INVEST")).toUpperCase(),
          account: String(getValByHeader(f, fMap, ["account"], 3, "CASH")).toUpperCase(),
          entity: String(getValByHeader(f, fMap, ["entity"], 4, "")).trim(),
          amount: Math.round(Number(getValByHeader(f, fMap, ["amount (₹)", "amount"], 5, 0))) || 0,
          narration: String(getValByHeader(f, fMap, ["narration"], 6, "")).trim()
        });
      }
    });
  }

  var users = [];
  var userSheet = ss.getSheetByName("Users");
  if (userSheet && userSheet.getLastRow() > 1) {
    var uMap = buildHeaderMap(userSheet);
    var uData = userSheet.getRange(2, 1, userSheet.getLastRow() - 1, userSheet.getLastColumn()).getValues();
    uData.forEach(function(u) {
      var uname = String(getValByHeader(u, uMap, ["username"], 0, ""));
      if (uname) {
        users.push({
          username: uname,
          password: String(getValByHeader(u, uMap, ["password"], 1, "12345")),
          role: String(getValByHeader(u, uMap, ["role"], 2, "Manager")),
          email: String(getValByHeader(u, uMap, ["email"], 3, "")),
          status: String(getValByHeader(u, uMap, ["status"], 4, "ACTIVE"))
        });
      }
    });
  }

  var sheetUrl = "";
  try { sheetUrl = ss.getUrl(); } catch(e) {}
  return { members: members, payments: payments, loans: loans, exitSettlements: exitSettlements, bonusSettlements: bonusSettlements, fundTransactions: fundTransactions, users: users, spreadsheetUrl: sheetUrl };
}

function getSocietyFullData() {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    if (!ss) return getDefaultDataFallback();
    try { upgradeUsersSheetCredentials(); } catch(e) {}
    var memSheet = ss.getSheetByName("Members");
    if (!memSheet || memSheet.getLastRow() <= 1) { installAndRunDatabase(); memSheet = ss.getSheetByName("Members"); }

    var res = getSocietyFullDataWithoutFinSync();
    if (res.members && res.members.length > 0) {
      syncFinancialsSheetBackend();
    }
    return res;
  } catch (e) {
    return getDefaultDataFallback();
  }
}

function getDefaultDataFallback() {
  return {
    members: [
      { id: "MEM010120261", name: "Rahul Kumar", mobile: "9810011111", status: "ACTIVE", address: "H-12, Sector 3, Rohini", nominee: "Sunita Kumar", rd: 400, dateJoined: "2026-01-01", rdPaid: 4800, dueDay: "15th of every month", customLimit: 0, opLoan: 0, opInt: 0, opPen: 0 },
      { id: "MEM010120262", name: "Suresh Sharma", mobile: "9810022222", status: "ACTIVE", address: "Shop 4, Market", nominee: "Vikas", rd: 400, dateJoined: "2026-01-01", rdPaid: 4400, dueDay: "15th of every month", customLimit: 0, opLoan: 0, opInt: 0, opPen: 0 },
      { id: "MEM010120263", name: "Amit Verma", mobile: "9810033333", status: "ACTIVE", address: "B-45, Shastri Nagar", nominee: "Pooja", rd: 400, dateJoined: "2026-01-01", rdPaid: 4400, dueDay: "15th of every month", customLimit: 0, opLoan: 0, opInt: 0, opPen: 0 },
      { id: "MEM010120264", name: "SANISH", mobile: "9718174244", status: "ACTIVE", address: "ASD", nominee: "DFFF", rd: 400, dateJoined: "2026-01-01", rdPaid: 1000, dueDay: "15th of every month", customLimit: 0, opLoan: 0, opInt: 0, opPen: 0 }
    ],
    payments: [],
    loans: [],
    exitSettlements: [],
    bonusSettlements: [],
    fundTransactions: [
      { id: "FND-260101-001", date: "2026-01-01", type: "INVEST", account: "BANK", entity: "Initial Society Capital", amount: 45000, narration: "Opening Reserve Fund" }
    ],
    users: [
      { username: "SANISH", password: "12345", role: "Super Admin", email: "stfsolutionsdelhi@gmail.com" },
      { username: "ADMIN", password: "12345", role: "Manager", email: "stfsolutionsdelhi@gmail.com" }
    ]
  };
}

function checkUserLoginBackend(username, password) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var uInp = String(username || "SANISH").trim().toUpperCase();
    var pInp = String(password || "").trim();

    if (!pInp) {
      return { success: false, error: "⚠️ Password khali nahi ho sakta!" };
    }

    if (ss) {
      var uSheet = ss.getSheetByName("Users");
      if (!uSheet || uSheet.getLastRow() <= 1) {
        installAndRunDatabase();
        uSheet = ss.getSheetByName("Users");
      }
      if (uSheet && uSheet.getLastRow() > 1) {
        var data = uSheet.getRange(2, 1, uSheet.getLastRow() - 1, 5).getValues();
        var foundUser = null;
        for (var i = 0; i < data.length; i++) {
          var u = String(data[i][0] || "").trim().toUpperCase();
          var p = String(data[i][1] || "").trim();
          var role = String(data[i][2] || "Manager").trim();
          var status = String(data[i][4] || "ACTIVE").trim().toUpperCase();
          if (u === uInp) {
            foundUser = { username: u, password: p, role: role, status: status };
            break;
          }
        }

        if (foundUser) {
          if (foundUser.password === pInp || (pInp === "12345" && (foundUser.password === "12345" || foundUser.password === "Password" || foundUser.password === ""))) {
            return { success: true, user: { username: foundUser.username, role: foundUser.role } };
          } else {
            return { success: false, error: "❌ Galat Password! Kripya Google Sheet me darj sahi password bharein." };
          }
        }
      }
    }

    if ((uInp === "SANISH" || uInp === "ADMIN") && (pInp === "12345" || pInp === "Password" || pInp === "Admin@123")) {
      return { success: true, user: { username: uInp, role: (uInp === "ADMIN" ? "Manager" : "Super Admin") } };
    }
    return { success: false, error: "❌ Username ya Password galat hai." };
  } catch (err) {
    return { success: false, error: "Login check failed: " + err.message };
  }
}

function saveMemberBackend(m) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet(); if (!ss) return { success: true };
    var sheet = ss.getSheetByName("Members"); if (!sheet) { installAndRunDatabase(); sheet = ss.getSheetByName("Members"); }
    var lastRow = sheet.getLastRow(); var updated = false;
    var safeRd = Math.round(Number(m.rd)) || 400;
    var safeOpRd = Math.round(Number(m.rdPaid)) || 0;

    var rowVals = [
      m.id,
      m.name,
      m.mobile,
      m.address||"",
      m.nominee||"",
      safeRd,
      m.status||"ACTIVE",
      formatPureDate(m.dateJoined||"2026-01-01"),
      safeOpRd,
      m.dueDay||"15th of every month",
      Math.round(Number(m.customLimit))||0,
      Math.round(Number(m.opLoan))||0,
      Math.round(Number(m.opInt))||0,
      Math.round(Number(m.opPen))||0
    ];

    if (lastRow > 1) {
      var ids = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
      for (var i = 0; i < ids.length; i++) {
        if (String(ids[i][0]) === String(m.id)) {
          sheet.getRange(i + 2, 1, 1, 14).setValues([rowVals]);
          updated = true; break;
        }
      }
    }
    if (!updated) sheet.appendRow(rowVals);
    SpreadsheetApp.flush();
    return { success: true };
  } catch (e) { return { success: false, error: e.toString() }; }
}

function savePaymentBackend(p) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet(); if (!ss) return { success: true };
    var sheet = ss.getSheetByName("Payments"); if (!sheet) { installAndRunDatabase(); sheet = ss.getSheetByName("Payments"); }
    var safeMode = String(p.mode||"CASH").toUpperCase().indexOf("ONLINE") >= 0 ? "ONLINE" : "CASH";
    
    var lastRow = sheet.getLastRow();
    var updated = false;
    if (lastRow > 1) {
      var recNos = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
      for (var i = 0; i < recNos.length; i++) {
        if (String(recNos[i][0]) === String(p.receiptNo)) {
          sheet.getRange(i + 2, 1, 1, 14).setValues([[
            p.receiptNo, formatPureDate(p.date), p.id, p.name,
            Math.round(Number(p.rd))||0, Math.round(Number(p.interest))||0,
            Math.round(Number(p.penalty))||0, Math.round(Number(p.loanRepay))||0,
            Math.round(Number(p.waiver))||0, Math.round(Number(p.total))||0,
            safeMode, "Admin", p.type||"REGULAR", p.narration||""
          ]]);
          updated = true; break;
        }
      }
    }

    if (!updated) {
      sheet.appendRow([
        p.receiptNo, formatPureDate(p.date), p.id, p.name,
        Math.round(Number(p.rd))||0, Math.round(Number(p.interest))||0,
        Math.round(Number(p.penalty))||0, Math.round(Number(p.loanRepay))||0,
        Math.round(Number(p.waiver))||0, Math.round(Number(p.total))||0,
        safeMode, "Admin", p.type||"REGULAR", p.narration||""
      ]);
    }
    SpreadsheetApp.flush();
    return { success: true };
  } catch (e) { return { success: false, error: e.toString() }; }
}

function saveLoanBackend(l) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet(); if (!ss) return { success: true };
    var sheet = ss.getSheetByName("Loans"); if (!sheet) { installAndRunDatabase(); sheet = ss.getSheetByName("Loans"); }
    
    var lastRow = sheet.getLastRow();
    var updated = false;
    if (lastRow > 1) {
      var lIds = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
      for (var i = 0; i < lIds.length; i++) {
        if (String(lIds[i][0]) === String(l.loanId)) {
          sheet.getRange(i + 2, 1, 1, 11).setValues([[
            l.loanId, formatPureDate(l.date), l.id, l.name, l.type||"Gullak Loan",
            Math.round(Number(l.principal))||0, Number(l.rate)||1.0,
            Math.round(Number(l.repaid))||0, Math.round(Number(l.outstanding))||0, l.status||"ACTIVE", l.narration||""
          ]]);
          updated = true; break;
        }
      }
    }

    if (!updated) {
      sheet.appendRow([l.loanId, formatPureDate(l.date), l.id, l.name, l.type||"Gullak Loan", Math.round(Number(l.principal))||0, Number(l.rate)||1.0, Math.round(Number(l.repaid))||0, Math.round(Number(l.outstanding))||l.principal, l.status||"ACTIVE", l.narration||""]);
    }
    SpreadsheetApp.flush();
    return { success: true };
  } catch (e) { return { success: false, error: e.toString() }; }
}

function saveExitSettlementBackend(ex) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet(); if (!ss) return { success: true };
    var sheet = ss.getSheetByName("ExitSettlements"); if (!sheet) { installAndRunDatabase(); sheet = ss.getSheetByName("ExitSettlements"); }
    sheet.appendRow([ex.exitId, formatPureDate(ex.date), ex.id, ex.name, Math.round(Number(ex.totalRd))||0, Math.round(Number(ex.loanDues))||0, Math.round(Number(ex.bonusAdj))||0, Math.round(Number(ex.npaLoss))||0, Math.round(Number(ex.waiver))||0, Math.round(Number(ex.netSettlement))||0, "INACTIVE"]);
    SpreadsheetApp.flush();
    return { success: true };
  } catch (e) { return { success: false, error: e.toString() }; }
}

function saveBonusSettlementBackend(b) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet(); if (!ss) return { success: true };
    var sheet = ss.getSheetByName("BonusSettlements"); if (!sheet) { installAndRunDatabase(); sheet = ss.getSheetByName("BonusSettlements"); }
    var safeMode = String(b.mode||"ONLINE").toUpperCase().indexOf("CASH") >= 0 ? "CASH" : "ONLINE";
    sheet.appendRow([b.settlementId, formatPureDate(b.date), b.id, b.name, Math.round(Number(b.totalBonus))||0, Math.round(Number(b.adjLoan))||0, Math.round(Number(b.adjInterest))||0, Math.round(Number(b.adjRd))||0, Math.round(Number(b.adjPenalty))||0, Math.round(Number(b.netPaid))||0, safeMode]);
    SpreadsheetApp.flush();
    return { success: true };
  } catch (e) { return { success: false, error: e.toString() }; }
}

function saveFundTransactionBackend(entry) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    if (!ss) return { success: false, error: "No active spreadsheet found" };
    var fH = ["Txn ID", "Date", "Type", "Account", "Entity", "Amount (₹)", "Narration", "CreatedAt"];
    var fSheet = getOrCreateSheet(ss, "FundRegister", fH, "#4338CA");
    
    var txnId = entry.id || ("FND-" + formatPureDate(entry.date).replace(/-/g, "").substring(2) + "-001");
    var row = [
      txnId,
      formatPureDate(entry.date || new Date()),
      String(entry.type || "INVEST").toUpperCase(),
      String(entry.account || "CASH").toUpperCase(),
      String(entry.entity || "Society Capital").trim(),
      Math.round(Number(entry.amount)) || 0,
      String(entry.narration || "").trim(),
      new Date()
    ];

    var updated = false;
    var lastRow = fSheet.getLastRow();
    if (lastRow > 1) {
      var ids = fSheet.getRange(2, 1, lastRow - 1, 1).getValues();
      for (var i = 0; i < ids.length; i++) {
        if (String(ids[i][0]).trim().toUpperCase() === String(txnId).trim().toUpperCase()) {
          fSheet.getRange(i + 2, 1, 1, row.length).setValues([row]);
          updated = true;
          break;
        }
      }
    }

    if (!updated) {
      fSheet.appendRow(row);
    }
    SpreadsheetApp.flush();
    return { success: true, message: "Fund entry saved successfully", id: txnId, updated: updated };
  } catch(e) {
    return { success: false, error: e.toString() };
  }
}

function doGet(e) {
  return HtmlService.createHtmlOutput(getCompleteSoftwareHtml())
    .setTitle("GULLAK CO-OPERATIVE SOCIETY - Master Accounting Platform (V43 PRO)")
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
    .addMetaTag("viewport", "width=device-width, initial-scale=1.0");
}

function doPost(e) {
  return doGet(e);
}
